// Контрольная модуля 1 · Вариант A · Библиотека колледжа
// 80 минут · 20 баллов. Пишите код под каждым заданием. Результат — на странице index.html.
// Под каждым заданием — ожидаемый ответ: совпало, значит верно.
// Можно пользоваться своими файлами уроков 1–6. Нельзя: ИИ-ассистенты и помощь соседа.
//
// Вывод на страницу: print(...), renderCard(obj, "Имя"), renderTable(arr, "Имя")
//
// Сдача: репозиторий js-m1 на GitHub → GitHub Pages → ссылку в чат группы
//   git init → git add . → git commit -m "Контрольная М1" → git remote add origin … → git branch -M main → git push -u origin main

// Данные пришли с сервера строкой JSON. Строку не меняйте.
const response = `[
  {"title":"Жамийля","author":"  чингиз айтматов","genre":"повесть","year":1958,"copies":5,"taken":5,"rating":4.8},
  {"title":"Белый пароход","author":"ЧИНГИЗ АЙТМАТОВ","genre":"Повесть ","year":1970,"copies":4,"taken":2,"rating":4.7},
  {"title":"Мастер и Маргарита","author":"михаил булгаков","genre":"роман","year":1967,"copies":6,"taken":4,"rating":4.9},
  {"title":"Чистый код","author":"роберт мартин ","genre":"IT","year":2008,"copies":3,"taken":3,"rating":4.6},
  {"title":"Грокаем алгоритмы","author":"адитья бхаргава","genre":"it","year":2016,"copies":4,"taken":1,"rating":4.5},
  {"title":"451 градус по Фаренгейту","author":"рэй брэдбери","genre":" роман","year":1953,"copies":2,"taken":0,"rating":4.4},
  {"title":"Манас","author":"сагымбай орозбаков","genre":"Эпос","year":1922,"copies":3,"taken":1,"rating":5.0},
  {"title":"Выразительный JavaScript","author":"марейн хавербеке","genre":"IT ","year":2018,"copies":5,"taken":4,"rating":4.3},
  {"title":"Пегий пёс, бегущий краем моря","author":" чингиз   айтматов ","genre":"повесть","year":1977,"copies":2,"taken":2,"rating":4.6},
  {"title":"Преступление и наказание","author":"фёдор достоевский","genre":"Роман","year":1866,"copies":4,"taken":3,"rating":4.7}
]`;

// 1. books — массив из строки (JSON.parse). Выведите количество → 10 и renderTable(books, "Как пришло")


// 2. function capitalize(word) и function cleanName(name) — имя в нормальном виде
//    cleanName(" чингиз   айтматов ") → "Чингиз Айтматов"


// 3. function freeCopies(book) — сколько экземпляров свободно: copies - taken
//    freeCopies(books[1]) → 2


// 4. catalog — новый массив (map + spread): author через cleanName, genre без пробелов и строчными,
//    новое поле free из задания 3. renderTable(catalog, "Каталог")


// 5. canTake — книги, которые можно взять (free > 0) → 7


// 6. onHands — сколько всего экземпляров на руках (сумма taken) → 25


// 7. function byGenre(list, genre) — жанр, регистр и пробелы не важны
//    byGenre(catalog, " РОМАН ").length → 3, byGenre(catalog, "повесть").length → 3


// 8. Топ-3 по рейтингу: копия, sort, slice, map — только названия
//    → Манас, Мастер и Маргарита, Жамийля


// 9. stats — сколько в каждом жанре (reduce, начальное значение {})
//    renderCard(stats, "Книг по жанрам") → повесть 3, роман 3, it 3, эпос 1


// 10. function search(list, text) — поиск по названию или автору, регистр и пробелы не важны
//    search(catalog, "айтматов") → 3, search(catalog, " JAVASCRIPT") → 1


// 11. JSON.stringify массива canTake, где у каждого элемента только title и free → print


// ★ (бонус) Есть ли полностью выданные книги (free === 0) → true. Все ли книги изданы после 1900 года → false

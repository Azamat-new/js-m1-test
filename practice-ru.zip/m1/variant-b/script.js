// Контрольная модуля 1 · Вариант B · Кинотеатр
// 80 минут · 20 баллов. Пишите код под каждым заданием. Результат — на странице index.html.
// Под каждым заданием — ожидаемый ответ: совпало, значит верно.
// Можно пользоваться своими файлами уроков 1–6. Нельзя: ИИ-ассистенты и помощь соседа.
//
// Вывод на страницу: print(...), renderCard(obj, "Имя"), renderTable(arr, "Имя")
//
// Сдача: репозиторий js-m1 на GitHub → GitHub Pages → ссылку в чат группы
//   git init → git add . → git commit -m "Контрольная М1" → git remote add origin … → git branch -M main → git push -u origin main

// Данные пришли с сервера строкой JSON. Строку не меняйте.
const response = `[
  {"title":"Дюна: Часть вторая","director":"  дени вильнёв","genre":"фантастика","hall":"Зал 1","seats":120,"sold":120,"price":450,"rating":4.8},
  {"title":"Боз салкын","director":"ЭРНЕСТ АБДЫЖАПАРОВ","genre":"Драма ","hall":"Зал 2","seats":80,"sold":52,"price":350,"rating":4.7},
  {"title":"Интерстеллар","director":"кристофер нолан","genre":"фантастика","hall":"Зал 1","seats":120,"sold":96,"price":400,"rating":4.9},
  {"title":"Головоломка 2","director":"келси манн ","genre":"Мультфильм","hall":"Зал 3","seats":60,"sold":60,"price":300,"rating":4.5},
  {"title":"Оппенгеймер","director":"кристофер  нолан","genre":" драма","hall":"Зал 2","seats":80,"sold":30,"price":400,"rating":4.6},
  {"title":"Ходячий замок","director":"хаяо миядзаки","genre":"мультфильм","hall":"Зал 3","seats":60,"sold":44,"price":250,"rating":5.0},
  {"title":"Бегущий по лезвию 2049","director":"дени вильнёв","genre":"ФАНТАСТИКА","hall":"Зал 1","seats":120,"sold":0,"price":350,"rating":4.4},
  {"title":"Зелёная книга","director":"питер фаррелли","genre":"драма","hall":"Зал 2","seats":80,"sold":80,"price":300,"rating":4.6},
  {"title":"Холодное сердце","director":"крис бак","genre":"мультфильм ","hall":"Зал 3","seats":60,"sold":18,"price":250,"rating":4.3},
  {"title":"Марсианин","director":" ридли   скотт ","genre":"Фантастика","hall":"Зал 1","seats":120,"sold":75,"price":350,"rating":4.6}
]`;

// 1. sessions — массив из строки (JSON.parse). Выведите количество → 10 и renderTable(sessions, "Как пришло")


// 2. function capitalize(word) и function cleanName(name) — имя в нормальном виде
//    cleanName(" ридли   скотт ") → "Ридли Скотт"


// 3. function freeSeats(session) — сколько мест свободно: seats - sold
//    freeSeats(sessions[1]) → 28


// 4. afisha — новый массив (map + spread): director через cleanName, genre без пробелов и строчными,
//    новое поле free из задания 3. renderTable(afisha, "Афиша")


// 5. canBuy — сеансы, где есть билеты (free > 0) → 7


// 6. revenue — выручка: сумма sold * price по всем сеансам → 206350


// 7. function byGenre(list, genre) — жанр, регистр и пробелы не важны
//    byGenre(afisha, " ДРАМА ").length → 3, byGenre(afisha, "фантастика").length → 4


// 8. Топ-3 по рейтингу: копия, sort, slice, map — только названия
//    → Ходячий замок, Интерстеллар, Дюна: Часть вторая


// 9. stats — сколько в каждом жанре (reduce, начальное значение {})
//    renderCard(stats, "Сеансов по жанрам") → фантастика 4, драма 3, мультфильм 3


// 10. function search(list, text) — поиск по названию или режиссёру, регистр и пробелы не важны
//    search(afisha, "нолан") → 2, search(afisha, " ЗАМОК") → 1


// 11. JSON.stringify массива canBuy, где у каждого элемента только title и free → print


// ★ (бонус) Есть ли распроданные сеансы (free === 0) → true. Все ли билеты стоят от 300 сом → false

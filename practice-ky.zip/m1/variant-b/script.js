// 1-модулдун текшерүү иши · B варианты · Кинотеатр
// 80 мүнөт · 20 балл. Кодду ар бир тапшырманын астына жазыңыз. Натыйжа — index.html барагында.
// Ар бир тапшырманын астында — күтүлгөн жооп: дал келсе, туура.
// 1–6-сабактардагы өз файлдарыңызды колдонсоңуз болот. Болбойт: ИИ-жардамчылар жана коңшунун жардамы.
//
// Баракка чыгаруу: print(...), renderCard(obj, "Аты"), renderTable(arr, "Аты")
//
// Тапшыруу: GitHub'тагы js-m1 репозиторийи → GitHub Pages → шилтемени топтун чатына
//   git init → git add . → git commit -m "М1 текшерүү иши" → git remote add origin … → git branch -M main → git push -u origin main

// Маалымат серверден JSON сап болуп келди. Сапты өзгөртпөңүз.
const response = `[
  {"title":"Дюна: Часть вторая","director":"  дени вильнёв","genre":"фантастика","hall":"Зал 1","seats":120,"sold":120,"price":450,"rating":4.8},
  {"title":"Боз салкын","director":"ЭРНЕСТ АБДЫЖАПАРОВ","genre":"Драма ","hall":"Зал 2","seats":80,"sold":52,"price":350,"rating":4.7},
  {"title":"Интерстеллар","director":"кристофер нолан","genre":"фантастика","hall":"Зал 1","seats":120,"sold":96,"price":400,"rating":4.9},
  {"title":"Головоломка 2","director":"келси манн ","genre":"Мультфильм","hall":"Зал 3","seats":60,"sold":60,"price":300,"rating":4.5},
  {"title":"Оппенгеймер","director":"кристофер  нолан","genre":" драма","hall":"Зал 2","seats":80,"sold":30,"price":400,"rating":4.6},
  {"title":"Ходячий замок","director":"хаяо миядзаки","genre":"мультфильм","hall":"Зал 3","seats":60,"sold":44,"price":250,"rating":5.0},
  {"title":"Бегущий по лезвию 2049","director":"дени вильнёв","genre":"ФАНТАСТИКА","hall":"Зал 1","seats":120,"sold":0,"price":350,"rating":4.4},
  {"title":"Зелёная книга","director":"питер фаррелли","genre":"драма","hall":"Зал 2","seats":80,"sold":80,"price":300,"rating":4.6},
  {"title":"Холодное сердце","director":"крис бак","genre":"мультфильм ","hall":"Зал 3","seats":60,"sold":18,"price":250,"rating":4.3},
  {"title":"Марсианин","director":" ридли   скотт ","genre":"Фантастика","hall":"Зал 1","seats":120,"sold":75,"price":350,"rating":4.6}
]`;

// 1. sessions — саптан массив (JSON.parse). Санын чыгарыңыз → 10 жана renderTable(sessions, "Кандай келди")


// 2. function capitalize(word) жана function cleanName(name) — атты туура түргө келтирүү
//    cleanName(" ридли   скотт ") → "Ридли Скотт"


// 3. function freeSeats(session) — канча орун бош: seats - sold
//    freeSeats(sessions[1]) → 28


// 4. afisha — жаңы массив (map + spread): director cleanName аркылуу, genre боштуксуз жана кичине тамга менен,
//    3-тапшырмадагы жаңы free талаасы. renderTable(afisha, "Афиша")


// 5. canBuy — билети бар сеанстар (free > 0) → 7


// 6. revenue — киреше: бардык сеанстар боюнча sold * price суммасы → 206350


// 7. function byGenre(list, genre) — жанр, регистр жана боштуктар маанилүү эмес
//    byGenre(afisha, " ДРАМА ").length → 3, byGenre(afisha, "фантастика").length → 4


// 8. Рейтинг боюнча топ-3: көчүрмө, sort, slice, map — аталыштары гана
//    → Ходячий замок, Интерстеллар, Дюна: Часть вторая


// 9. stats — ар бир жанрда канча (reduce, баштапкы мааниси {})
//    renderCard(stats, "Жанрлар боюнча сеанстар") → фантастика 4, драма 3, мультфильм 3


// 10. function search(list, text) — аталышы же режиссёру боюнча издөө, регистр жана боштуктар маанилүү эмес
//    search(afisha, "нолан") → 2, search(afisha, " ЗАМОК") → 1


// 11. canBuy массивинин JSON.stringify'ы, ар бир элементте title жана free гана → print


// ★ (бонус) Бардык билеттери сатылган сеанстар барбы (free === 0) → true. Бардык билеттер 300 сомдон кымбатпы → false

/*
  render.js — готовые функции вывода на страницу.
  Пока просто пользуйтесь ими. На уроке 8 (DOM) разберём, как они устроены,
  и вы напишете такие же сами.

  print(...значения)          — строка в блоке «Вывод» (как console.log, но на странице)
  renderCard(объект, заголовок) — карточка «ключ: значение» для любого объекта
  renderShop(товары, заголовок) — витрина из массива объектов-товаров
      поля товара: name, price, oldPrice, category, inStock, rating
  renderTable(массив, заголовок) — таблица из массива любых объектов
*/
(() => {
  const ky = (document.documentElement.lang || '').startsWith('ky');
  const T = ky
    ? { out: 'Натыйжа', obj: 'Объект', shop: 'Витрина', none: 'Жок', method: 'метод', empty: 'Бош', err: 'Ката', cur: 'сом', items: 'товар', notArr: 'renderShop массив күтөт', noName: 'аты жок' }
    : { out: 'Вывод', obj: 'Объект', shop: 'Витрина', none: 'Нет в наличии', method: 'метод', empty: 'Пусто', err: 'Ошибка', cur: 'сом', items: 'товаров', notArr: 'renderShop ожидает массив', noName: 'без названия' };

  const css = `
  :root{--bg:#f5f3ef;--paper:#fff;--ink:#1d1d1b;--muted:#77736b;--line:#e2ded6;--accent:#c8553d;--ok:#2f7d4f}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 Inter,system-ui,-apple-system,"Segoe UI",sans-serif}
  .r-wrap{max-width:1100px;margin:0 auto;padding:32px 20px 60px}
  .r-wrap > header{border-bottom:2px solid var(--ink);padding-bottom:14px;margin-bottom:28px}
  .r-wrap > header h1{margin:0;font-size:30px;letter-spacing:-.01em}
  .r-wrap > header p{margin:6px 0 0;color:var(--muted)}
  .r-sec{margin:0 0 32px}
  .r-sec h2{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:var(--accent);margin:0 0 12px}
  .r-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
  .r-prod{background:var(--paper);border:1px solid var(--line);border-radius:10px;overflow:hidden;display:flex;flex-direction:column}
  .r-prod .ph{height:110px;display:flex;align-items:center;justify-content:center;font-size:44px;font-weight:700;color:#fff}
  .r-prod .b{padding:14px 16px 16px;display:flex;flex-direction:column;gap:4px;flex:1}
  .r-prod .cat{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
  .r-prod .nm{font-weight:600;font-size:17px}
  .r-prod .pr{margin-top:auto;font-size:20px;font-weight:700}
  .r-prod .old{color:var(--muted);text-decoration:line-through;font-weight:400;font-size:15px;margin-left:8px}
  .r-prod .rt{font-size:13px;color:var(--muted)}
  .r-prod .tag{position:absolute;margin:10px;background:var(--accent);color:#fff;font-size:12px;font-weight:700;padding:3px 8px;border-radius:4px}
  .r-prod.out{opacity:.5}
  .r-prod.out .pr::after{content:" · ${T.none}";font-size:13px;font-weight:400;color:var(--muted)}
  .r-prod{position:relative}
  .r-card{background:var(--paper);border:1px solid var(--line);border-radius:10px;padding:6px 18px;max-width:640px}
  .r-row{display:flex;gap:16px;padding:9px 0;border-bottom:1px solid var(--line)}
  .r-row:last-child{border-bottom:0}
  .r-row .k{min-width:150px;color:var(--muted);font-family:"JetBrains Mono",ui-monospace,monospace;font-size:14px;padding-top:2px}
  .r-row .v{flex:1;word-break:break-word}
  .r-row .v .r-card{border:0;padding:0 0 0 12px;border-left:2px solid var(--line);border-radius:0}
  .r-fn{font-family:"JetBrains Mono",ui-monospace,monospace;font-size:14px;color:var(--accent)}
  .r-out{background:#1d1d1b;color:#ece8e1;border-radius:10px;padding:14px 18px;font-family:"JetBrains Mono",ui-monospace,monospace;font-size:14px;white-space:pre-wrap}
  .r-out div{padding:3px 0;border-bottom:1px solid #34322e}
  .r-out div:last-child{border-bottom:0}
  .r-out .e{color:#ff8a73}
  .r-muted{color:var(--muted)}
  .r-tbl{width:100%;border-collapse:collapse;background:var(--paper);border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .r-tbl th{text-align:left;font-family:"JetBrains Mono",ui-monospace,monospace;font-size:13px;font-weight:500;color:var(--muted);background:#faf8f4;padding:10px 14px;border-bottom:1px solid var(--line)}
  .r-tbl td{padding:10px 14px;border-bottom:1px solid var(--line)}
  .r-tbl tr:last-child td{border-bottom:0}
  .r-tbl .y{font-weight:600}.r-tbl .n{color:var(--muted)}`;

  const COLORS = ['#c8553d', '#2f6f8f', '#4f7d3a', '#8a5a9b', '#b07d2a', '#3d5a80', '#7a4b3a'];
  const color = s => COLORS[[...String(s)].reduce((a, c) => a + c.charCodeAt(0), 0) % COLORS.length];
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const money = n => typeof n === 'number' ? n.toLocaleString('ru-RU') + ' ' + T.cur : esc(n);

  let wrap, outBox;
  const ready = () => {
    if (wrap) return;
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    wrap = document.createElement('div'); wrap.className = 'r-wrap';
    const h = document.querySelector('body > header');
    if (h) wrap.appendChild(h);
    document.body.prepend(wrap);
  };
  const section = title => {
    ready();
    const s = document.createElement('section'); s.className = 'r-sec';
    s.innerHTML = `<h2>${esc(title)}</h2>`;
    if (outBox) wrap.insertBefore(s, outBox.parentNode); else wrap.appendChild(s);
    return s;
  };

  const fmt = v => {
    if (typeof v === 'string') return v;
    if (typeof v === 'function') return 'f()';
    if (v === undefined) return 'undefined';
    if (typeof v === 'number' || typeof v === 'boolean' || v === null) return String(v);
    try { return JSON.stringify(v, (k, x) => typeof x === 'function' ? 'f()' : x, Array.isArray(v) && v.every(x => typeof x !== 'object') ? 0 : 2); } catch (e) { return String(v); }
  };
  const line = (text, cls) => {
    ready();
    if (!outBox) {
      const s = document.createElement('section'); s.className = 'r-sec';
      s.innerHTML = `<h2>${T.out}</h2>`;
      outBox = document.createElement('div'); outBox.className = 'r-out';
      s.appendChild(outBox); wrap.appendChild(s);
    }
    const d = document.createElement('div'); if (cls) d.className = cls; d.textContent = text;
    outBox.appendChild(d);
  };

  window.print = (...vals) => { console.log(...vals); line(vals.map(fmt).join(' ')); };

  const value = v => {
    if (typeof v === 'function') return `<span class="r-fn">${T.method}()</span>`;
    if (Array.isArray(v)) return v.length ? v.map(x => typeof x === 'object' && x ? cardHtml(x) : esc(fmt(x))).join(typeof v[0] === 'object' ? '' : ', ') : `<span class="r-muted">[ ]</span>`;
    if (v && typeof v === 'object') return cardHtml(v);
    if (v === undefined || v === null || v === '') return `<span class="r-muted">${esc(String(v === '' ? '""' : v))}</span>`;
    return esc(v);
  };
  const cardHtml = obj => {
    const keys = Object.keys(obj);
    if (!keys.length) return `<div class="r-card"><div class="r-row"><span class="r-muted">${T.empty} { }</span></div></div>`;
    return `<div class="r-card">${keys.map(k => `<div class="r-row"><span class="k">${esc(k)}</span><span class="v">${value(obj[k])}</span></div>`).join('')}</div>`;
  };

  window.renderCard = (obj, title = T.obj) => {
    console.log(title, obj);
    const s = section(title);
    if (!obj || typeof obj !== 'object') { s.insertAdjacentHTML('beforeend', `<div class="r-out"><div class="e">${esc(fmt(obj))}</div></div>`); return; }
    s.insertAdjacentHTML('beforeend', cardHtml(obj));
  };

  window.renderShop = (products, title = T.shop) => {
    console.log(title, products);
    if (!Array.isArray(products)) { line(T.err + ': ' + T.notArr, 'e'); return; }
    const s = section(`${title} · ${T.items}: ${products.length}`);
    const g = document.createElement('div'); g.className = 'r-grid';
    g.innerHTML = products.map(p => {
      p = p || {};
      const name = p.name || p.title || T.noName;
      const sale = typeof p.oldPrice === 'number' && typeof p.price === 'number' && p.oldPrice > p.price;
      return `<article class="r-prod${p.inStock === false ? ' out' : ''}">
        ${sale ? `<span class="tag">−${Math.round((1 - p.price / p.oldPrice) * 100)}%</span>` : ''}
        <div class="ph" style="background:${color(p.category || name)}">${esc(String(name).trim()[0] || '?').toUpperCase()}</div>
        <div class="b">
          ${p.category ? `<span class="cat">${esc(p.category)}</span>` : ''}
          <span class="nm">${esc(name)}</span>
          ${p.rating !== undefined ? `<span class="rt">${esc(p.rating)} / 5</span>` : ''}
          <span class="pr">${p.price !== undefined ? money(p.price) : '—'}${sale ? `<span class="old">${money(p.oldPrice)}</span>` : ''}</span>
        </div></article>`;
    }).join('');
    s.appendChild(g);
  };

  window.renderTable = (rows, title = T.obj) => {
    console.log(title, rows);
    if (!Array.isArray(rows)) { line(T.err + ': renderTable ' + T.notArr.split(' ').slice(1).join(' '), 'e'); return; }
    const s = section(`${title} · ${rows.length}`);
    const cols = [...new Set(rows.flatMap(r => r && typeof r === 'object' ? Object.keys(r) : []))].filter(k => typeof rows.find(r => r && k in r)[k] !== 'function');
    const cell = v => v === true ? '<span class="y">true</span>' : v === false ? '<span class="n">false</span>' : v === undefined ? '<span class="r-muted">—</span>' : esc(typeof v === 'object' ? fmt(v) : v);
    s.insertAdjacentHTML('beforeend', `<table class="r-tbl"><tr>${cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr>${rows.map(r => `<tr>${cols.map(c => `<td>${cell((r || {})[c])}</td>`).join('')}</tr>`).join('')}</table>`);
  };

  window.addEventListener('error', e => line(`${T.err}: ${e.message}${e.lineno ? ` (${(e.filename || '').split('/').pop()}:${e.lineno})` : ''}`, 'e'));
})();

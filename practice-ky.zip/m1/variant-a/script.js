// 1-модулдун текшерүү иши · A варианты · Колледждин китепканасы
// 80 мүнөт · 20 балл. Кодду ар бир тапшырманын астына жазыңыз. Натыйжа — index.html барагында.
// Ар бир тапшырманын астында — күтүлгөн жооп: дал келсе, туура.
// 1–6-сабактардагы өз файлдарыңызды колдонсоңуз болот. Болбойт: ИИ-жардамчылар жана коңшунун жардамы.
//
// Баракка чыгаруу: print(...), renderCard(obj, "Аты"), renderTable(arr, "Аты")
//
// Тапшыруу: GitHub'тагы js-m1 репозиторийи → GitHub Pages → шилтемени топтун чатына
//   git init → git add . → git commit -m "М1 текшерүү иши" → git remote add origin … → git branch -M main → git push -u origin main

// Маалымат серверден JSON сап болуп келди. Сапты өзгөртпөңүз.
const response = `[
  {"title":"Жамийля","author":"  чингиз айтматов","genre":"повесть","year":1958,"copies":5,"taken":5,"rating":4.8},
  {"title":"Белый пароход","author":"ЧИНГИЗ АЙТМАТОВ","genre":"Повесть ","year":1970,"copies":4,"taken":2,"rating":4.7},
  {"title":"Мастер и Маргарита","author":"михаил булгаков","genre":"роман","year":1967,"copies":6,"taken":4,"rating":4.9},
  {"title":"Чистый код","author":"роберт мартин ","genre":"IT","year":2008,"copies":3,"taken":3,"rating":4.6},
  {"title":"Грокаем алгоритмы","author":"адитья бхаргава","genre":"it","year":2016,"copies":4,"taken":1,"rating":4.5},
  {"title":"451 градус по Фаренгейту","author":"рэй брэдбери","genre":" роман","year":1953,"copies":2,"taken":0,"rating":4.4},
  {"title":"Манас","author":"сагымбай орозбаков","genre":"Эпос","year":1922,"copies":3,"taken":1,"rating":5.0},
  {"title":"Выразительный JavaScript","author":"марейн хавербеке","genre":"IT ","year":2018,"copies":5,"taken":4,"rating":4.3},
  {"title":"Пегий пёс, бегущий краем моря","author":" чингиз   айтматов ","genre":"повесть","year":1977,"copies":2,"taken":2,"rating":4.6},
  {"title":"Преступление и наказание","author":"фёдор достоевский","genre":"Роман","year":1866,"copies":4,"taken":3,"rating":4.7}
]`;

// 1. books — саптан массив (JSON.parse). Санын чыгарыңыз → 10 жана renderTable(books, "Кандай келди")


// 2. function capitalize(word) жана function cleanName(name) — атты туура түргө келтирүү
//    cleanName(" чингиз   айтматов ") → "Чингиз Айтматов"


// 3. function freeCopies(book) — канча нуска бош: copies - taken
//    freeCopies(books[1]) → 2


// 4. catalog — жаңы массив (map + spread): author cleanName аркылуу, genre боштуксуз жана кичине тамга менен,
//    3-тапшырмадагы жаңы free талаасы. renderTable(catalog, "Каталог")


// 5. canTake — алууга боло турган китептер (free > 0) → 7


// 6. onHands — окурмандардын колунда жалпы канча нуска (taken суммасы) → 25


// 7. function byGenre(list, genre) — жанр, регистр жана боштуктар маанилүү эмес
//    byGenre(catalog, " РОМАН ").length → 3, byGenre(catalog, "повесть").length → 3


// 8. Рейтинг боюнча топ-3: көчүрмө, sort, slice, map — аталыштары гана
//    → Манас, Мастер и Маргарита, Жамийля


// 9. stats — ар бир жанрда канча (reduce, баштапкы мааниси {})
//    renderCard(stats, "Жанрлар боюнча китептер") → повесть 3, роман 3, it 3, эпос 1


// 10. function search(list, text) — аталышы же автору боюнча издөө, регистр жана боштуктар маанилүү эмес
//    search(catalog, "айтматов") → 3, search(catalog, " JAVASCRIPT") → 1


// 11. canTake массивинин JSON.stringify'ы, ар бир элементте title жана free гана → print


// ★ (бонус) Толугу менен берилген китептер барбы (free === 0) → true. Бардык китептер 1900-жылдан кийин чыкканбы → false
